package com.example.demo.model;

public enum TaskStatus {
  PENDIENTE, EN_PROGRESO, COMPLETADA
}
